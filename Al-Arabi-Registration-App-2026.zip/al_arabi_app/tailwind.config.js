/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        amiri: ['Amiri', 'serif'],
        cairo: ['Cairo', 'sans-serif'],
      },
      colors: {
        mahogany: {
          950: '#160904',
          900: '#240E07',
          800: '#36150B',
        },
        gold: {
          300: '#F5E1A4',
          400: '#E2BE6F',
          500: '#C59B27',
          600: '#9A7416',
        }
      }
    },
  },
  plugins: [],
}
