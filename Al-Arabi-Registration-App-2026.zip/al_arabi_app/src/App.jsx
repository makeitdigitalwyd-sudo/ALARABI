import React, { useState, useEffect, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import {
  Sparkles,
  Upload,
  CheckCircle2,
  Copy,
  Check,
  Shield,
  Users,
  Award,
  Calendar,
  Phone,
  Search,
  Download,
  Eye,
  X,
  Radio,
  Trash2,
  UserCheck,
  Clock,
  AlertCircle,
  ExternalLink,
  Hash
} from 'lucide-react';
import {
  collection,
  addDoc,
  onSnapshot,
  doc,
  updateDoc,
  deleteDoc,
  setDoc,
  query,
  orderBy,
  serverTimestamp
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from './firebase';

const UPI_NUMBER = '9072584470';
const UPI_ID = '9072584470@upi';
const REGISTRATION_FEE = 50;
const ADMIN_PIN = '2026';

// 3D Tilt Card Wrapper Component
function Tilt3DCard({ children, className = '' }) {
  const cardRef = useRef(null);
  const [transform, setTransform] = useState('perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)');

  const handleMouseMove = (e) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = ((y - centerY) / centerY) * -8;
    const rotateY = ((x - centerX) / centerX) * 8;
    setTransform(`perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`);
  };

  const handleMouseLeave = () => {
    setTransform('perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)');
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{ transform, transition: 'transform 0.2s ease-out' }}
      className={`preserve-3d ${className}`}
    >
      {children}
    </div>
  );
}

// Islamic Geometric Star SVG Ornament
function IslamicStarOrnament({ className = 'w-8 h-8' }) {
  return (
    <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      <polygon
        points="50,5 61,25 85,25 73,45 85,65 61,65 50,85 39,65 15,65 27,45 15,25 39,25"
        stroke="#C59B27"
        strokeWidth="2.5"
        fill="rgba(197, 155, 39, 0.12)"
      />
      <circle cx="50" cy="45" r="14" stroke="#F5E1A4" strokeWidth="1.5" />
      <circle cx="50" cy="45" r="4" fill="#C59B27" />
    </svg>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState('register'); // 'register' | 'admin'
  const [registrations, setRegistrations] = useState([]);
  const [announcement, setAnnouncement] = useState(
    'أهلاً بكم في مسابقة العربي لاكتشاف البطل في اللغة العربية — ١٩ ديسمبر ٢٠٢٦'
  );
  const [syncMode, setSyncMode] = useState(isFirebaseConfigured ? 'firebase' : 'local-live');

  // Form States
  const [participantName, setParticipantName] = useState('');
  const [participantAge, setParticipantAge] = useState('');
  const [collegeName, setCollegeName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [screenshotData, setScreenshotData] = useState('');
  const [screenshotName, setScreenshotName] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [submittedPass, setSubmittedPass] = useState(null);
  const [formError, setFormError] = useState('');

  // Admin States
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [previewImage, setPreviewImage] = useState(null);
  const [newAnnouncement, setNewAnnouncement] = useState('');

  // Real-time Sync Setup (Firebase Firestore with seamless local BroadcastChannel fallback)
  useEffect(() => {
    if (isFirebaseConfigured && db) {
      setSyncMode('firebase');
      const q = query(collection(db, 'registrations'), orderBy('createdAt', 'desc'));
      const unsubRegs = onSnapshot(
        q,
        (snapshot) => {
          const list = snapshot.docs.map((d) => ({
            id: d.id,
            ...d.data(),
          }));
          setRegistrations(list);
        },
        (err) => {
          console.error('Firestore error:', err);
        }
      );

      const unsubSettings = onSnapshot(doc(db, 'settings', 'live'), (docSnap) => {
        if (docSnap.exists() && docSnap.data().announcement) {
          setAnnouncement(docSnap.data().announcement);
        }
      });

      return () => {
        unsubRegs();
        unsubSettings();
      };
    } else {
      setSyncMode('local-live');
      const loadLocal = () => {
        try {
          const saved = JSON.parse(localStorage.getItem('alarabi_registrations') || '[]');
          setRegistrations(saved);
          const savedAnn = localStorage.getItem('alarabi_announcement');
          if (savedAnn) setAnnouncement(savedAnn);
        } catch (e) {
          console.error(e);
        }
      };
      loadLocal();

      const channel = new BroadcastChannel('alarabi_live_sync');
      channel.onmessage = () => loadLocal();
      window.addEventListener('storage', loadLocal);

      return () => {
        channel.close();
        window.removeEventListener('storage', loadLocal);
      };
    }
  }, []);

  const broadcastLocalUpdate = () => {
    const channel = new BroadcastChannel('alarabi_live_sync');
    channel.postMessage({ type: 'UPDATE', timestamp: Date.now() });
    channel.close();
  };

  // Compress uploaded payment screenshot so it fits cleanly in Firestore/Storage
  const handleImageUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setScreenshotName(file.name);
    setFormError('');

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxWidth = 800;
        const scale = Math.min(1, maxWidth / img.width);
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.72);
        setScreenshotData(compressedBase64);
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  };

  const handleCopyUpiNumber = () => {
    navigator.clipboard.writeText(UPI_NUMBER);
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 2500);
  };

  const handleSubmitRegistration = async (e) => {
    e.preventDefault();
    setFormError('');

    if (!participantName.trim() || !participantAge.trim() || !collegeName.trim()) {
      setFormError('يرجى تعبئة جميع الحقول المطلوبة (الاسم، العمر، الكلية).');
      return;
    }
    if (!screenshotData) {
      setFormError('يرجى إرفاق لقطة شاشة لإيصال الدفع (٥٠ روبية).');
      return;
    }

    setSubmitting(true);
    const regCode = `ARB-${Math.floor(1000 + Math.random() * 9000)}`;
    const newEntry = {
      regCode,
      name: participantName.trim(),
      age: participantAge.trim(),
      college: collegeName.trim(),
      phone: phoneNumber.trim() || 'غير مرفق',
      fee: REGISTRATION_FEE,
      screenshot: screenshotData,
      status: 'pending', // 'pending' | 'verified' | 'rejected'
      chestNumber: '',
      submittedAt: new Date().toLocaleString('ar-EG'),
      createdAt: Date.now(),
    };

    try {
      if (isFirebaseConfigured && db) {
        await addDoc(collection(db, 'registrations'), {
          ...newEntry,
          createdAt: serverTimestamp(),
        });
      } else {
        const current = JSON.parse(localStorage.getItem('alarabi_registrations') || '[]');
        const updated = [{ id: regCode, ...newEntry }, ...current];
        localStorage.setItem('alarabi_registrations', JSON.stringify(updated));
        setRegistrations(updated);
        broadcastLocalUpdate();
      }

      setSubmittedPass(newEntry);
      setParticipantName('');
      setParticipantAge('');
      setCollegeName('');
      setPhoneNumber('');
      setScreenshotData('');
      setScreenshotName('');
    } catch (err) {
      console.error(err);
      setFormError('حدث خطأ أثناء الإرسال. يرجى المحاولة مرة أخرى.');
    } finally {
      setSubmitting(false);
    }
  };

  // Admin Actions
  const handleAdminUnlock = (e) => {
    e.preventDefault();
    if (pinInput === ADMIN_PIN) {
      setIsAdminUnlocked(true);
      setPinError('');
    } else {
      setPinError('رمز الدخول غير صحيح');
    }
  };

  const updateCandidateStatus = async (id, status) => {
    if (isFirebaseConfigured && db) {
      await updateDoc(doc(db, 'registrations', id), { status });
    } else {
      const updated = registrations.map((r) => (r.id === id ? { ...r, status } : r));
      localStorage.setItem('alarabi_registrations', JSON.stringify(updated));
      setRegistrations(updated);
      broadcastLocalUpdate();
    }
  };

  const updateChestNumber = async (id, chestNumber) => {
    if (isFirebaseConfigured && db) {
      await updateDoc(doc(db, 'registrations', id), { chestNumber });
    } else {
      const updated = registrations.map((r) => (r.id === id ? { ...r, chestNumber } : r));
      localStorage.setItem('alarabi_registrations', JSON.stringify(updated));
      setRegistrations(updated);
      broadcastLocalUpdate();
    }
  };

  const deleteCandidate = async (id) => {
    if (!window.confirm('هل أنت متأكد من حذف هذا المشارك؟')) return;
    if (isFirebaseConfigured && db) {
      await deleteDoc(doc(db, 'registrations', id));
    } else {
      const updated = registrations.filter((r) => r.id !== id);
      localStorage.setItem('alarabi_registrations', JSON.stringify(updated));
      setRegistrations(updated);
      broadcastLocalUpdate();
    }
  };

  const handleBroadcastAnnouncement = async (e) => {
    e.preventDefault();
    if (!newAnnouncement.trim()) return;
    if (isFirebaseConfigured && db) {
      await setDoc(doc(db, 'settings', 'live'), { announcement: newAnnouncement.trim() }, { merge: true });
    } else {
      localStorage.setItem('alarabi_announcement', newAnnouncement.trim());
      setAnnouncement(newAnnouncement.trim());
      broadcastLocalUpdate();
    }
    setNewAnnouncement('');
  };

  const exportToCSV = () => {
    const headers = ['رمز التسجيل', 'رقم الصدر', 'اسم المشارك', 'العمر', 'الكلية', 'الهاتف', 'الحالة', 'وقت التسجيل'];
    const rows = registrations.map((r) => [
      r.regCode,
      r.chestNumber || '-',
      `"${r.name}"`,
      r.age,
      `"${r.college}"`,
      r.phone,
      r.status === 'verified' ? 'مؤكد' : r.status === 'rejected' ? 'مرفوض' : 'قيد المراجعة',
      `"${r.submittedAt}"`
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,﻿' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'Al_Arabi_Participants_2026.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredRegistrations = registrations.filter((r) => {
    const matchesSearch =
      r.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.college?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.regCode?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || r.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const upiLink = `upi://pay?pa=${UPI_ID}&pn=Al%20Arabi%20DHIU&am=${REGISTRATION_FEE}&cu=INR&tn=AlArabiRegistration`;

  const verifiedCount = registrations.filter((r) => r.status === 'verified').length;
  const pendingCount = registrations.filter((r) => r.status === 'pending').length;

  return (
    <div className="min-h-screen bg-[#160904] text-[#FAF3E6] relative overflow-x-hidden">
      {/* Ambient Radial Golden Spotlight & Mashrabiya Geometric Backdrop */}
      <div
        className="fixed inset-0 pointer-events-none opacity-30"
        style={{
          backgroundImage: `radial-gradient(circle at 50% 15%, rgba(197, 155, 39, 0.35), transparent 60%),
            repeating-linear-gradient(45deg, rgba(197,155,39,0.04) 0px, rgba(197,155,39,0.04) 2px, transparent 2px, transparent 24px),
            repeating-linear-gradient(-45deg, rgba(197,155,39,0.04) 0px, rgba(197,155,39,0.04) 2px, transparent 2px, transparent 24px)`
        }}
      />

      {/* Top Decorative Islamic Geometric Frame Border */}
      <div className="h-3 w-full bg-gradient-to-r from-[#5c4314] via-[#F5E1A4] to-[#5c4314] shadow-lg" />

      {/* Live Stage Announcement Ticker */}
      <div className="bg-[#240E07]/90 border-b border-[#C59B27]/30 backdrop-blur-md py-2 px-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between gap-3 text-xs sm:text-sm">
          <div className="flex items-center gap-2 text-[#F5E1A4] font-semibold">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="whitespace-nowrap">بث مباشر:</span>
          </div>
          <p className="text-[#E8D5B5] truncate flex-1 text-center font-medium">{announcement}</p>
          <span className="hidden sm:inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full bg-[#C59B27]/15 border border-[#C59B27]/40 text-[#F5E1A4]">
            <Radio className="w-3 h-3 animate-pulse" />
            {syncMode === 'firebase' ? 'سحابة حية' : 'تحديث فوري'}
          </span>
        </div>
      </div>

      {/* Navigation Switcher */}
      <header className="relative z-10 max-w-5xl mx-auto pt-6 px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <IslamicStarOrnament className="w-10 h-10" />
          <div>
            <p className="text-xs text-[#E2BE6F] tracking-wide font-semibold">جامعة دار الهدى الإسلامية</p>
            <p className="text-[11px] text-[#E8D5B5]/80">قسم اللغة العربية وآدابها</p>
          </div>
        </div>

        <nav className="flex items-center bg-[#240E07]/90 p-1.5 rounded-2xl border border-[#C59B27]/35 shadow-xl">
          <button
            onClick={() => setActiveTab('register')}
            className={`px-5 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${
              activeTab === 'register'
                ? 'bg-gradient-to-r from-[#C59B27] to-[#E2BE6F] text-[#160904] shadow-md'
                : 'text-[#E8D5B5] hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            بوابة التسجيل
          </button>
          <button
            onClick={() => setActiveTab('admin')}
            className={`px-5 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${
              activeTab === 'admin'
                ? 'bg-gradient-to-r from-[#C59B27] to-[#E2BE6F] text-[#160904] shadow-md'
                : 'text-[#E8D5B5] hover:text-white'
            }`}
          >
            <Shield className="w-4 h-4" />
            لوحة الإدارة
            <span className="bg-[#160904]/30 px-2 py-0.5 rounded-full text-xs">{registrations.length}</span>
          </button>
        </nav>
      </header>

      <main className="relative z-10 max-w-5xl mx-auto px-4 py-8">
        {activeTab === 'register' ? (
          <div className="space-y-10">
            {/* Hero Poster Header */}
            <section className="text-center space-y-4">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#240E07] border border-[#C59B27]/40 text-[#F5E1A4] text-xs sm:text-sm shadow-lg">
                <Calendar className="w-4 h-4 text-[#C59B27]" />
                <span>١٩ ديسمبر ٢٠٢٦ • كلية اللغات والآداب</span>
              </div>

              <h1 className="font-amiri text-6xl sm:text-8xl font-bold gold-gradient-text drop-shadow-[0_6px_24px_rgba(197,155,39,0.35)] leading-tight">
                العربي
              </h1>

              <p className="text-lg sm:text-2xl font-bold text-[#FAF3E6]">
                مسابقة لاكتشاف البطل في اللغة العربية
              </p>
              <p className="max-w-2xl mx-auto text-xs sm:text-sm text-[#E8D5B5]/85 leading-relaxed">
                مسابقة ينظمها قسم اللغة العربية وآدابها التابع لكلية اللغات والآداب بجامعة دار الهدى الإسلامية،
                يستهدف من خلالها اختيار طالب متألق في اللغة العربية في جوانبها المختلفة.
              </p>

              {/* 3D Interactive Prize Medallions (4444 / 3333 / 2222) */}
              <div className="grid grid-cols-3 gap-3 sm:gap-6 max-w-2xl mx-auto pt-4">
                <Tilt3DCard className="bg-gradient-to-b from-[#2E130A] to-[#1D0B05] border border-[#C59B27]/40 rounded-2xl p-4 sm:p-5 text-center shadow-2xl">
                  <div className="w-9 h-9 mx-auto mb-2 rounded-full bg-[#C59B27]/15 border border-[#C59B27]/50 flex items-center justify-center">
                    <Award className="w-5 h-5 text-[#E2BE6F]" />
                  </div>
                  <p className="text-xs sm:text-sm text-[#E8D5B5] font-semibold">المركز الثاني</p>
                  <p className="font-amiri text-2xl sm:text-4xl font-bold text-[#F5E1A4] mt-1">3333</p>
                </Tilt3DCard>

                <Tilt3DCard className="bg-gradient-to-b from-[#3D1A0E] to-[#240E07] border-2 border-[#E2BE6F] rounded-2xl p-4 sm:p-6 text-center shadow-[0_10px_35px_rgba(197,155,39,0.28)] -translate-y-2">
                  <div className="w-11 h-11 mx-auto mb-2 rounded-full bg-gradient-to-br from-[#F5E1A4] to-[#C59B27] flex items-center justify-center shadow-lg">
                    <Award className="w-6 h-6 text-[#160904]" />
                  </div>
                  <p className="text-xs sm:text-sm text-[#F5E1A4] font-bold">المركز الأول</p>
                  <p className="font-amiri text-3xl sm:text-5xl font-bold gold-gradient-text mt-1">4444</p>
                </Tilt3DCard>

                <Tilt3DCard className="bg-gradient-to-b from-[#2E130A] to-[#1D0B05] border border-[#C59B27]/40 rounded-2xl p-4 sm:p-5 text-center shadow-2xl">
                  <div className="w-9 h-9 mx-auto mb-2 rounded-full bg-[#C59B27]/15 border border-[#C59B27]/50 flex items-center justify-center">
                    <Award className="w-5 h-5 text-[#E2BE6F]" />
                  </div>
                  <p className="text-xs sm:text-sm text-[#E8D5B5] font-semibold">المركز الثالث</p>
                  <p className="font-amiri text-2xl sm:text-4xl font-bold text-[#F5E1A4] mt-1">2222</p>
                </Tilt3DCard>
              </div>
            </section>

            {/* Submitted 3D Entry Pass Modal/Card */}
            {submittedPass ? (
              <div className="max-w-lg mx-auto">
                <Tilt3DCard className="bg-gradient-to-br from-[#2B1108] via-[#1E0B05] to-[#2B1108] border-2 border-[#E2BE6F] rounded-3xl p-6 sm:p-8 shadow-[0_20px_60px_rgba(197,155,39,0.35)] text-center space-y-5">
                  <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 border border-emerald-400 flex items-center justify-center">
                    <CheckCircle2 className="w-9 h-9 text-emerald-400" />
                  </div>
                  <div>
                    <span className="text-xs px-3 py-1 rounded-full bg-[#C59B27]/20 text-[#F5E1A4] border border-[#C59B27]/40">
                      بطاقة مشارك معتمدة • {submittedPass.regCode}
                    </span>
                    <h2 className="font-amiri text-3xl font-bold text-[#F5E1A4] mt-3">
                      تم استلام طلب تسجيلك بنجاح!
                    </h2>
                    <p className="text-xs text-[#E8D5B5] mt-1">
                      تم إرسال بياناتك وإيصال الدفع مباشرة إلى لجنة المسابقة
                    </p>
                  </div>

                  <div className="bg-[#160904]/80 border border-[#C59B27]/30 rounded-2xl p-4 text-right space-y-2.5 text-sm">
                    <div className="flex justify-between border-b border-[#C59B27]/15 pb-2">
                      <span className="text-[#E8D5B5]/70">اسم المشارك:</span>
                      <span className="font-bold text-[#FAF3E6]">{submittedPass.name}</span>
                    </div>
                    <div className="flex justify-between border-b border-[#C59B27]/15 pb-2">
                      <span className="text-[#E8D5B5]/70">عمر المشارك:</span>
                      <span className="font-bold text-[#FAF3E6]">{submittedPass.age} سنة</span>
                    </div>
                    <div className="flex justify-between border-b border-[#C59B27]/15 pb-2">
                      <span className="text-[#E8D5B5]/70">الكلية:</span>
                      <span className="font-bold text-[#FAF3E6]">{submittedPass.college}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#E8D5B5]/70">رسوم التسجيل:</span>
                      <span className="font-bold text-emerald-400">₹50 (مرفق الإيصال)</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setSubmittedPass(null)}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-[#C59B27] to-[#E2BE6F] text-[#160904] font-bold text-sm hover:opacity-95 transition"
                  >
                    تسجيل مشارك آخر
                  </button>
                </Tilt3DCard>
              </div>
            ) : (
              /* Main Registration + QR Payment Split Grid */
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Payment QR Code Card */}
                <div className="lg:col-span-5">
                  <Tilt3DCard className="bg-[#240E07]/90 border border-[#C59B27]/45 rounded-3xl p-6 shadow-2xl gold-border-glow space-y-5">
                    <div className="flex items-center justify-between border-b border-[#C59B27]/20 pb-3">
                      <div>
                        <h2 className="font-amiri text-2xl font-bold text-[#F5E1A4]">رسوم التسجيل</h2>
                        <p className="text-xs text-[#E8D5B5]/80">امسح الرمز أو حوّل عبر UPI</p>
                      </div>
                      <div className="px-3.5 py-1.5 rounded-xl bg-[#C59B27]/20 border border-[#C59B27]/50 text-[#F5E1A4] font-extrabold text-lg">
                        ₹50
                      </div>
                    </div>

                    {/* Scannable White Framed QR Code */}
                    <div className="bg-white p-4 rounded-2xl w-fit mx-auto shadow-[0_10px_30px_rgba(0,0,0,0.5)] border-4 border-[#C59B27]">
                      <QRCodeSVG
                        value={upiLink}
                        size={185}
                        bgColor="#FFFFFF"
                        fgColor="#160904"
                        level="H"
                      />
                    </div>

                    {/* Payment Number Box */}
                    <div className="bg-[#160904]/90 border border-[#C59B27]/35 rounded-2xl p-3.5 flex items-center justify-between">
                      <div>
                        <p className="text-[11px] text-[#E8D5B5]/70">رقم الدفع (GPay / PhonePe / Paytm)</p>
                        <p className="text-base sm:text-lg font-bold tracking-wider text-[#F5E1A4]" dir="ltr">
                          +91 90725 84470
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={handleCopyUpiNumber}
                        className="px-3 py-2 rounded-xl bg-[#C59B27]/20 hover:bg-[#C59B27]/30 border border-[#C59B27]/40 text-[#F5E1A4] text-xs font-semibold flex items-center gap-1.5 transition"
                      >
                        {copiedPhone ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                        {copiedPhone ? 'تم النسخ' : 'نسخ'}
                      </button>
                    </div>

                    <a
                      href={upiLink}
                      className="w-full py-2.5 px-4 rounded-xl bg-[#C59B27]/15 hover:bg-[#C59B27]/25 border border-[#C59B27]/40 text-[#F5E1A4] text-xs font-bold flex items-center justify-center gap-2 transition"
                    >
                      <ExternalLink className="w-4 h-4" />
                      فتح تطبيق الدفع مباشرة (UPI App)
                    </a>
                  </Tilt3DCard>
                </div>

                {/* Candidate Registration Form */}
                <div className="lg:col-span-7">
                  <form
                    onSubmit={handleSubmitRegistration}
                    className="bg-[#240E07]/90 border border-[#C59B27]/45 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-5"
                  >
                    <div className="border-b border-[#C59B27]/20 pb-3">
                      <h2 className="font-amiri text-2xl sm:text-3xl font-bold text-[#F5E1A4]">
                        استمارة تسجيل المشارك
                      </h2>
                      <p className="text-xs text-[#E8D5B5]/80 mt-0.5">
                        أدخل بياناتك بدقة وأرفق صورة إيصال تحويل مبلغ ٥٠ روبية
                      </p>
                    </div>

                    {formError && (
                      <div className="p-3.5 rounded-xl bg-red-950/70 border border-red-500/50 text-red-200 text-xs flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                        <span>{formError}</span>
                      </div>
                    )}

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-bold text-[#F5E1A4] mb-1.5">
                          اسم المشارك <span className="text-red-400">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          value={participantName}
                          onChange={(e) => setParticipantName(e.target.value)}
                          placeholder="أدخل الاسم الكامل للمشارك"
                          className="w-full px-4 py-3 rounded-xl bg-[#160904] border border-[#C59B27]/40 focus:border-[#F5E1A4] focus:outline-none text-[#FAF3E6] placeholder-[#E8D5B5]/35 text-sm"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-bold text-[#F5E1A4] mb-1.5">
                            عمر المشارك <span className="text-red-400">*</span>
                          </label>
                          <input
                            type="number"
                            min="12"
                            max="45"
                            required
                            value={participantAge}
                            onChange={(e) => setParticipantAge(e.target.value)}
                            placeholder="مثال: 20"
                            className="w-full px-4 py-3 rounded-xl bg-[#160904] border border-[#C59B27]/40 focus:border-[#F5E1A4] focus:outline-none text-[#FAF3E6] placeholder-[#E8D5B5]/35 text-sm"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-bold text-[#F5E1A4] mb-1.5">
                            رقم الواتساب للتواصل
                          </label>
                          <input
                            type="tel"
                            value={phoneNumber}
                            onChange={(e) => setPhoneNumber(e.target.value)}
                            placeholder="مثال: 9876543210"
                            className="w-full px-4 py-3 rounded-xl bg-[#160904] border border-[#C59B27]/40 focus:border-[#F5E1A4] focus:outline-none text-[#FAF3E6] placeholder-[#E8D5B5]/35 text-sm"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-bold text-[#F5E1A4] mb-1.5">
                          كلية <span className="text-red-400">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          value={collegeName}
                          onChange={(e) => setCollegeName(e.target.value)}
                          placeholder="اسم الكلية أو المعهد"
                          className="w-full px-4 py-3 rounded-xl bg-[#160904] border border-[#C59B27]/40 focus:border-[#F5E1A4] focus:outline-none text-[#FAF3E6] placeholder-[#E8D5B5]/35 text-sm"
                        />
                      </div>

                      {/* Payment Screenshot Dropzone */}
                      <div>
                        <label className="block text-sm font-bold text-[#F5E1A4] mb-1.5">
                          إرفاق لقطة شاشة الدفع (Screenshot) <span className="text-red-400">*</span>
                        </label>
                        <label className="flex flex-col items-center justify-center w-full p-5 border-2 border-dashed border-[#C59B27]/45 hover:border-[#F5E1A4] rounded-2xl bg-[#160904]/70 cursor-pointer transition group">
                          {screenshotData ? (
                            <div className="flex items-center gap-4 w-full">
                              <img
                                src={screenshotData}
                                alt="إيصال الدفع"
                                className="w-16 h-16 object-cover rounded-xl border border-[#C59B27]"
                              />
                              <div className="flex-1 text-right overflow-hidden">
                                <p className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                                  <CheckCircle2 className="w-4 h-4" />
                                  تم إرفاق الإيصال بنجاح
                                </p>
                                <p className="text-[11px] text-[#E8D5B5]/70 truncate mt-0.5">{screenshotName}</p>
                                <p className="text-[11px] text-[#E2BE6F] underline mt-1">اضغط لتغيير الصورة</p>
                              </div>
                            </div>
                          ) : (
                            <div className="text-center space-y-1.5">
                              <div className="w-10 h-10 mx-auto rounded-full bg-[#C59B27]/15 flex items-center justify-center group-hover:scale-110 transition">
                                <Upload className="w-5 h-5 text-[#E2BE6F]" />
                              </div>
                              <p className="text-xs font-bold text-[#FAF3E6]">
                                اضغط لرفع لقطة شاشة تحويل مبلغ ٥٠ روبية
                              </p>
                              <p className="text-[11px] text-[#E8D5B5]/60">PNG, JPG أو JPEG</p>
                            </div>
                          )}
                          <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                        </label>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#C59B27] via-[#E2BE6F] to-[#C59B27] text-[#160904] font-extrabold text-base shadow-[0_8px_25px_rgba(197,155,39,0.35)] hover:brightness-105 active:scale-[0.99] transition disabled:opacity-50"
                    >
                      {submitting ? 'جاري إرسال التسجيل...' : 'تأكيد التسجيل وإصدار البطاقة'}
                    </button>
                  </form>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* LIVE ADMIN PROGRAM MANAGEMENT DASHBOARD */
          <div className="space-y-6">
            {!isAdminUnlocked ? (
              <div className="max-w-md mx-auto py-10">
                <form
                  onSubmit={handleAdminUnlock}
                  className="bg-[#240E07] border border-[#C59B27]/45 rounded-3xl p-8 text-center space-y-5 shadow-2xl"
                >
                  <div className="w-14 h-14 mx-auto rounded-2xl bg-[#C59B27]/20 border border-[#C59B27]/50 flex items-center justify-center">
                    <Shield className="w-7 h-7 text-[#F5E1A4]" />
                  </div>
                  <div>
                    <h2 className="font-amiri text-2xl font-bold text-[#F5E1A4]">لوحة إدارة البرنامج الحية</h2>
                    <p className="text-xs text-[#E8D5B5]/75 mt-1">أدخل رمز اللجنة المنظمة للوصول الفوري</p>
                  </div>
                  <input
                    type="password"
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value)}
                    placeholder="••••"
                    className="w-full text-center tracking-[0.5em] text-xl font-bold px-4 py-3 rounded-xl bg-[#160904] border border-[#C59B27]/40 focus:border-[#F5E1A4] focus:outline-none text-[#F5E1A4]"
                  />
                  {pinError && <p className="text-xs text-red-400">{pinError}</p>}
                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-[#C59B27] to-[#E2BE6F] text-[#160904] font-bold text-sm"
                  >
                    دخول الإدارة
                  </button>
                  <p className="text-[11px] text-[#E8D5B5]/50">الرمز الافتراضي: 2026</p>
                </form>
              </div>
            ) : (
              <>
                {/* Live KPI Metrics */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="bg-[#240E07] border border-[#C59B27]/35 rounded-2xl p-4">
                    <div className="flex items-center justify-between text-[#E8D5B5]/70 text-xs">
                      <span>إجمالي المسجلين</span>
                      <Users className="w-4 h-4 text-[#E2BE6F]" />
                    </div>
                    <p className="text-2xl sm:text-3xl font-extrabold text-[#F5E1A4] mt-2">{registrations.length}</p>
                  </div>

                  <div className="bg-[#240E07] border border-emerald-500/35 rounded-2xl p-4">
                    <div className="flex items-center justify-between text-emerald-300/80 text-xs">
                      <span>تم تأكيد الدفع</span>
                      <UserCheck className="w-4 h-4 text-emerald-400" />
                    </div>
                    <p className="text-2xl sm:text-3xl font-extrabold text-emerald-400 mt-2">{verifiedCount}</p>
                  </div>

                  <div className="bg-[#240E07] border border-amber-500/35 rounded-2xl p-4">
                    <div className="flex items-center justify-between text-amber-300/80 text-xs">
                      <span>قيد المراجعة</span>
                      <Clock className="w-4 h-4 text-amber-400" />
                    </div>
                    <p className="text-2xl sm:text-3xl font-extrabold text-amber-400 mt-2">{pendingCount}</p>
                  </div>

                  <div className="bg-[#240E07] border border-[#C59B27]/35 rounded-2xl p-4">
                    <div className="flex items-center justify-between text-[#E8D5B5]/70 text-xs">
                      <span>إجمالي الرسوم المؤكدة</span>
                      <Award className="w-4 h-4 text-[#E2BE6F]" />
                    </div>
                    <p className="text-2xl sm:text-3xl font-extrabold text-[#F5E1A4] mt-2">
                      ₹{verifiedCount * REGISTRATION_FEE}
                    </p>
                  </div>
                </div>

                {/* Live Stage Announcement Broadcaster */}
                <form
                  onSubmit={handleBroadcastAnnouncement}
                  className="bg-[#240E07] border border-[#C59B27]/35 rounded-2xl p-4 flex flex-col sm:flex-row gap-3 items-center"
                >
                  <div className="flex items-center gap-2 text-xs font-bold text-[#F5E1A4] whitespace-nowrap">
                    <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
                    <span>تحديث الشريط المباشر:</span>
                  </div>
                  <input
                    type="text"
                    value={newAnnouncement}
                    onChange={(e) => setNewAnnouncement(e.target.value)}
                    placeholder="اكتب إعلاناً فورياً يظهر لجميع المشاركين الآن..."
                    className="flex-1 w-full px-3.5 py-2 rounded-xl bg-[#160904] border border-[#C59B27]/30 text-xs text-[#FAF3E6] focus:outline-none focus:border-[#F5E1A4]"
                  />
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-4 py-2 rounded-xl bg-[#C59B27] text-[#160904] font-bold text-xs hover:brightness-110 transition whitespace-nowrap"
                  >
                    نشر فوري
                  </button>
                </form>

                {/* Filter & CSV Export Bar */}
                <div className="flex flex-col sm:flex-row gap-3 justify-between items-center bg-[#240E07] border border-[#C59B27]/35 rounded-2xl p-4">
                  <div className="relative w-full sm:w-72">
                    <Search className="w-4 h-4 text-[#E8D5B5]/50 absolute right-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="ابحث بالاسم، الكلية، أو الرمز..."
                      className="w-full pr-9 pl-3 py-2 rounded-xl bg-[#160904] border border-[#C59B27]/30 text-xs text-[#FAF3E6] focus:outline-none"
                    />
                  </div>

                  <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
                    {['all', 'pending', 'verified', 'rejected'].map((st) => (
                      <button
                        key={st}
                        onClick={() => setStatusFilter(st)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                          statusFilter === st
                            ? 'bg-[#C59B27] text-[#160904]'
                            : 'bg-[#160904] text-[#E8D5B5] border border-[#C59B27]/25'
                        }`}
                      >
                        {st === 'all'
                          ? 'الكل'
                          : st === 'pending'
                          ? 'قيد المراجعة'
                          : st === 'verified'
                          ? 'مؤكد'
                          : 'مرفوض'}
                      </button>
                    ))}

                    <button
                      onClick={exportToCSV}
                      className="px-3.5 py-1.5 rounded-xl bg-emerald-600/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1.5 hover:bg-emerald-600/30 transition"
                    >
                      <Download className="w-3.5 h-3.5" />
                      تصدير Excel/CSV
                    </button>
                  </div>
                </div>

                {/* Live Participant Cards List */}
                <div className="space-y-3">
                  {filteredRegistrations.length === 0 ? (
                    <div className="text-center py-14 bg-[#240E07]/60 border border-[#C59B27]/25 rounded-3xl text-[#E8D5B5]/60 text-sm">
                      لا توجد طلبات تسجيل مطابقة حالياً — ستظهر الطلبات الجديدة هنا تلقائياً فور إرسالها.
                    </div>
                  ) : (
                    filteredRegistrations.map((item) => (
                      <div
                        key={item.id}
                        className="bg-[#240E07] border border-[#C59B27]/35 rounded-2xl p-4 sm:p-5 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 hover:border-[#E2BE6F]/60 transition"
                      >
                        <div className="flex items-start gap-4">
                          {/* Payment Screenshot Thumbnail */}
                          <button
                            type="button"
                            onClick={() => setPreviewImage(item.screenshot)}
                            className="relative group w-16 h-16 rounded-xl overflow-hidden border border-[#C59B27]/50 shrink-0 bg-[#160904]"
                            title="عرض إيصال الدفع"
                          >
                            {item.screenshot ? (
                              <>
                                <img
                                  src={item.screenshot}
                                  alt={item.name}
                                  className="w-full h-full object-cover"
                                />
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
                                  <Eye className="w-5 h-5 text-white" />
                                </div>
                              </>
                            ) : (
                              <span className="text-[10px] text-[#E8D5B5]/50 flex items-center justify-center h-full">
                                بدون صورة
                              </span>
                            )}
                          </button>

                          <div className="space-y-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#160904] border border-[#C59B27]/30 text-[#E2BE6F]">
                                {item.regCode}
                              </span>
                              <h3 className="font-bold text-base text-[#FAF3E6]">{item.name}</h3>
                              <span
                                className={`text-[11px] px-2.5 py-0.5 rounded-full font-bold ${
                                  item.status === 'verified'
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                    : item.status === 'rejected'
                                    ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                }`}
                              >
                                {item.status === 'verified'
                                  ? 'مؤكد'
                                  : item.status === 'rejected'
                                  ? 'مرفوض'
                                  : 'قيد المراجعة'}
                              </span>
                            </div>

                            <p className="text-xs text-[#E8D5B5]">
                              <span className="text-[#E2BE6F]">الكلية:</span> {item.college} •{' '}
                              <span className="text-[#E2BE6F]">العمر:</span> {item.age} سنة •{' '}
                              <span className="text-[#E2BE6F]">الهاتف:</span> {item.phone}
                            </p>
                            <p className="text-[11px] text-[#E8D5B5]/50">{item.submittedAt}</p>
                          </div>
                        </div>

                        {/* Admin Controls: Chest Number + Approve/Reject */}
                        <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto justify-end border-t lg:border-t-0 border-[#C59B27]/15 pt-3 lg:pt-0">
                          <div className="flex items-center gap-1.5 bg-[#160904] border border-[#C59B27]/35 rounded-xl px-2.5 py-1.5">
                            <Hash className="w-3.5 h-3.5 text-[#E2BE6F]" />
                            <input
                              type="text"
                              value={item.chestNumber || ''}
                              onChange={(e) => updateChestNumber(item.id, e.target.value)}
                              placeholder="رقم الصدر"
                              className="w-20 bg-transparent text-xs text-[#FAF3E6] focus:outline-none"
                            />
                          </div>

                          <button
                            onClick={() => updateCandidateStatus(item.id, 'verified')}
                            className="px-3 py-1.5 rounded-xl bg-emerald-600/25 hover:bg-emerald-600/40 border border-emerald-500/40 text-emerald-300 text-xs font-bold transition"
                          >
                            قبول
                          </button>

                          <button
                            onClick={() => updateCandidateStatus(item.id, 'rejected')}
                            className="px-3 py-1.5 rounded-xl bg-amber-600/20 hover:bg-amber-600/35 border border-amber-500/40 text-amber-300 text-xs font-bold transition"
                          >
                            رفض
                          </button>

                          <button
                            onClick={() => deleteCandidate(item.id)}
                            className="p-1.5 rounded-xl bg-red-950/50 hover:bg-red-900/60 border border-red-500/30 text-red-300 transition"
                            title="حذف"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </>
            )}
          </div>
        )}
      </main>

      {/* Footer Contact Info from Poster */}
      <footer className="relative z-10 border-t border-[#C59B27]/25 bg-[#120703] mt-16 py-6 px-4 text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#240E07] border border-[#C59B27]/35 text-xs text-[#F5E1A4]">
          <Phone className="w-3.5 h-3.5 text-[#C59B27]" />
          <span>للمزيد من الاستفسارات:</span>
          <a href="tel:8590409367" className="font-bold tracking-wider underline" dir="ltr">
            8590409367
          </a>
        </div>
        <p className="text-xs text-[#E8D5B5]/70">
          قسم اللغة العربية وآدابها • جامعة دار الهدى الإسلامية
        </p>
      </footer>

      {/* Fullscreen Payment Screenshot Lightbox Modal */}
      {previewImage && (
        <div
          onClick={() => setPreviewImage(null)}
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <div className="relative max-w-lg w-full bg-[#240E07] border-2 border-[#C59B27] rounded-3xl p-3 shadow-2xl">
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute -top-4 -left-4 w-9 h-9 rounded-full bg-[#C59B27] text-[#160904] flex items-center justify-center shadow-lg font-bold"
            >
              <X className="w-5 h-5" />
            </button>
            <img src={previewImage} alt="إيصال الدفع الكامل" className="w-full max-h-[80vh] object-contain rounded-2xl" />
          </div>
        </div>
      )}
    </div>
  );
}
